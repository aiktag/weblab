const express = require('express')
const bodyParser = require('body-parser')
const mailer = require('./nodemailer')

const app = express()

const PORT = 3000
let user = undefined

app.use('/css', express.static(__dirname + '/node_modules/bootstrap/dist/css'))
app.use(bodyParser.urlencoded({ extended: false }))
app.post('/registration', (req, res) => { 
    if(!req.body.email || !req.body.pass) return res.sendStatus(400)   
    const message = {        
        to: req.body.email,
        subject: 'Congratulations!',
        text: `You are successfully registered
        
        Your account details:
        login: ${req.body.email}
        password: ${req.body.pass}
        
    `
    }
    mailer(message) 
    user = req.body 
    res.redirect('/registration') 
    
})
app.get('/registration', (req, res) => { 
    if(typeof user !== 'object') return res.sendFile(__dirname + '/registration.html')   
    res.send(`You successfully registered. You can see account details on: ${user.email} email`) 
    user = undefined  
})

app.listen(PORT, () => console.log(`server listening at http://localhost:${PORT}/registration`))