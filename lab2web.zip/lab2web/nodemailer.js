const nodemailer = require('nodemailer')

const transporter = nodemailer.createTransport(
    {
        host: 'smtp.mail.ru',
        port: 465,
        secure: true, 
        auth: {
            user: 'lab.web@mail.ru',
            pass: 'zQVrM9nkLaZcs6g96x2e'
        }
    },
    {
        from: 'lab.web@mail.ru>',
    }
)

const mailer = message => {
    transporter.sendMail(message, (err, info) => {
        if(err) return console.log(err)
        console.log('Email sent: ', info)
    })
}

module.exports = mailer